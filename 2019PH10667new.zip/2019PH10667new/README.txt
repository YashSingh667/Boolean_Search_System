Program contains two files.
Run invix.sh to generate the dictionary and termPostings File
Run boolsearch.sh to generate the Result File for boolean retrieval